<?php

die("Good day?");
?>